from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Create DB and Table if not exists
def init_db():
    conn = sqlite3.connect('donations.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS donations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            amount REAL,
            payment_mode TEXT,
            purpose TEXT,
            date TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form['name']
        amount = float(request.form['amount'])
        payment_mode = request.form['payment_mode']
        purpose = request.form['purpose']
        date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        conn = sqlite3.connect('donations.db')
        c = conn.cursor()
        c.execute("INSERT INTO donations (name, amount, payment_mode, purpose, date) VALUES (?, ?, ?, ?, ?)",
                  (name, amount, payment_mode, purpose, date))
        conn.commit()
        conn.close()
        return redirect('/')

    conn = sqlite3.connect('donations.db')
    c = conn.cursor()
    c.execute("SELECT * FROM donations")
    donations = c.fetchall()
    c.execute("SELECT SUM(amount), COUNT(DISTINCT name) FROM donations")
    total_stats = c.fetchone()
    conn.close()
    return render_template("index.html", donations=donations, total_stats=total_stats)

if __name__ == '__main__':
    app.run(debug=True)
